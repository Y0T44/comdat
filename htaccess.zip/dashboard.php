<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Navigation Bar -->
    <header>
        <nav>
            <h1>YourWebsite</h1>
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#">About</a></li>
                <li><a href="#">Contact</a></li>
                <li><a href="login.html">Login</a></li>
            </ul>
        </nav>
    </header>

    <!-- Login Form -->
    <section class="login-section">
        <div class="login-container">
            <h2>Login to Your Account</h2>
            <form id="loginForm">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
                
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
                
                <button type="submit">Login</button>
                <p>Don't have an account? <a href="signup.html">Sign up here</a></p>
            </form>
        </div>
    </section>

    <!-- Dashboard Placeholder -->
    <section class="dashboard" style="display:none;" id="dashboardSection">
        <h2>Welcome to Your Dashboard!</h2>
        <p>Hello, <span id="userWelcome"></span>! Here you can manage your account details.</p>
    </section>

    <script src="script.js"></script>
</body>
</html>
