function loadVoipData() {
    fetch('backend.php')
        .then(response => response.json())
        .then(data => {
            document.getElementById('content').innerHTML = `<p>${data.message}</p>`;
        })
        .catch(error => {
            console.error('Error:', error);
        });
}
