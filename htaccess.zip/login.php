<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #eaecef;
            color: #2c3e50;
            text-align: center;
            margin: 0;
            padding: 0;
        }

        header h1 {
            color: #3498db;
        }

        nav ul {
            list-style-type: none;
            padding: 0;
        }

        nav ul li {
            display: inline;
            margin: 0 15px;
        }

        nav ul li a {
            text-decoration: none;
            color: #2c3e50;
            font-weight: bold;
        }

        .login-section {
            margin: 50px auto;
            padding: 20px;
            max-width: 400px;
            background: #ffffff;
            border-radius: 15px;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1);
        }

        .login-container h2 {
            color: #34495e;
        }

        form label {
            display: block;
            margin-top: 10px;
            text-align: left;
            color: #34495e;
        }

        form input[type="text"],
        form input[type="password"] {
            width: calc(100% - 20px);
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #bdc3c7;
            border-radius: 10px;
        }

        button {
            margin-top: 20px;
            padding: 12px 25px;
            font-size: 16px;
            color: #ffffff;
            background-color: #2980b9;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #1f6391;
        }

        p a {
            color: #2980b9;
            text-decoration: none;
        }

        p a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<?php
session_start();

// Error handling settings for production
error_reporting(0);
ini_set('display_errors', 0);

// Database connection using environment variables for improved security
$servername = getenv('DB_SERVER');
$username = getenv('DB_USERNAME');
$password = getenv('DB_PASSWORD');
$database = getenv('DB_DATABASE');

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed. Please try again later.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = htmlspecialchars($_POST['username'], ENT_QUOTES, 'UTF-8');
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($hashed_password);
    $stmt->fetch();

    if ($stmt->num_rows > 0 && password_verify($password, $hashed_password)) {
        // Regenerate session ID to prevent session fixation
        session_regenerate_id(true);
        $_SESSION['username'] = $username;
        header('Location: dashboard.php');
        exit();
    } else {
        echo "<p style='color: red;'>Invalid credentials. Please try again.</p>";
    }
}
?>
    <!-- Navigation Bar -->
    <header>
        <nav>
            <h1>YourWebsite</h1>
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#">About</a></li>
                <li><a href="#">Contact</a></li>
                <li><a href="login.html">Login</a></li>
            </ul>
        </nav>
    </header>

    <!-- Login Form -->
    <section class="login-section">
        <div class="login-container">
            <h2>Login to Your Account</h2>
            <form method="post" action="">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
                
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
                
                <button type="submit">Login</button>
                <p>Don't have an account? <a href="signup.html">Sign up here</a></p>
            </form>
        </div>
    </section>

    <!-- Dashboard Placeholder -->
    <section class="dashboard" style="display:none;" id="dashboardSection">
        <h2>Welcome to Your Dashboard!</h2>
        <p>Hello, <span id="userWelcome"></span>! Here you can manage your account details.</p>
    </section>

    <script src="script.js"></script>
</body>
</html>
