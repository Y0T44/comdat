<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comdat VoIP Solutions</title>
    <link rel="stylesheet" href="styles.css">
    <script>
        function toggleLogin() {
            document.getElementById('login-form').style.display = 'block';
            document.getElementById('registration').style.display = 'none';
        }
    </script>
</head>
<body>
    <header>
        <h1>Comdat VoIP Solutions</h1>
        <p>Reliable, Branded VoIP Services for Your Business</p>
        <button onclick="toggleLogin()" class="button">Login</button>
    </header>
    <main>
        <!-- Registration Form -->
        <?php
        error_reporting(E_ALL);
        ini_set('display_errors', 1);

        // Database connection
        $conn = new mysqli("localhost", "comdatca_master", "Wirfo95f!", "comdatca_voip_users");

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            if (isset($_POST['register'])) {
                // Registration logic
                $username = $_POST['username'];
                $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

                $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
                $stmt->bind_param("ss", $username, $password);

                if ($stmt->execute()) {
                    echo "<p>Registration successful!</p>";
                } else {
                    echo "<p>Error: " . $stmt->error . "</p>";
                }
            } elseif (isset($_POST['login'])) {
                // Login logic
                $username = $_POST['username'];
                $password = $_POST['password'];

                $stmt = $conn->prepare("SELECT password FROM users WHERE username = ?");
                $stmt->bind_param("s", $username);
                $stmt->execute();
                $stmt->store_result();
                $stmt->bind_result($hashed_password);
                $stmt->fetch();

                if ($stmt->num_rows > 0 && password_verify($password, $hashed_password)) {
                    echo "<p>Login successful! Welcome, $username</p>";
                } else {
                    echo "<p>Invalid credentials</p>";
                }
            }
        }
        ?>
        <section id="registration">
            <h2>Register for VoIP Services</h2>
            <form method="post" action="">
                Username: <input type="text" name="username" required><br>
                Password: <input type="password" name="password" required><br>
                <input type="submit" name="register" value="Register">
            </form>
        </section>

        <section id="login-form" style="display:none;">
            <h2>Login to VoIP Services</h2>
            <form method="post" action="">
                Username: <input type="text" name="username" required><br>
                Password: <input type="password" name="password" required><br>
                <input type="submit" name="login" value="Login">
            </form>
        </section>

        <!-- Content for homepage -->
        <section id="features">
            <h2>Why Choose Our VoIP?</h2>
            <ul>
                <li>Professional Branding</li>
                <li>Cost Effective</li>
                <li>24/7 Reliability</li>
                <!-- More features -->
            </ul>
        </section>
    </main>
    <footer>
        <p>&copy; 2024 Comdat.ca - All Rights Reserved</p>
    </footer>
</body>
</html>
