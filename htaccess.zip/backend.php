<?php
// backend.php

// Database connection
$servername = "localhost";
$username = "comdatca_master";
$password = "Wirfo95f!";
$dbname = "comdatca_voip_users";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// API Call to VoIP.ms
$apiPassword = "Big_shit_10545";
$apiUrl = "https://voip.ms/api/v1/getData"; // Example endpoint

// Sample response (replace with real API call)
$response = array('message' => 'Data loaded successfully!');

// Send JSON response back to frontend
header('Content-Type: application/json');
echo json_encode($response);

$conn->close();
?>