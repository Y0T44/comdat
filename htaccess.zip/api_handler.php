<?php
require_once 'HTTP/Request2.php';
require_once 'Net/URL2.php';  // Include Net_URL2

// API password
$apiPassword = "Big_shit_10545";

// Create the base API URL
$apiBaseUrl = "https://voip.ms/api/v1/rest.php";

// Use Net_URL2 to build the full URL with query parameters
$url = new Net_URL2($apiBaseUrl);
$url->setQueryVariables([
    'method' => 'getBalance',
    'api_password' => $apiPassword
]);

// Use HTTP_Request2 to make the API request
try {
    $request = new HTTP_Request2();
    $request->setUrl($url->getURL());  // Use the URL built by Net_URL2
    $request->setMethod(HTTP_Request2::METHOD_GET);

    // Execute the request
    $response = $request->send();

    if (200 == $response->getStatus()) {
        echo $response->getBody();  // Output the API response
    } else {
        echo json_encode(['error' => 'API request failed with status ' . $response->getStatus()]);
    }
} catch (HTTP_Request2_Exception $e) {
    echo json_encode(['error' => 'Request failed: ' . $e->getMessage()]);
}
?>
