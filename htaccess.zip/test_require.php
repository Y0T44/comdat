<?php
// Enable error reporting
error_reporting(E_ALL); ini_set('display_errors', 1);
// Set the include path to include your custom library directory
ini_set("include_path", '/home/comdatca/php:' . 
ini_get("include_path")); require_once 'HTTP/Request2.php'; 
require_once 'Net/URL2.php'; echo "Dependencies are properly loaded."; 
?>
